import cv2

if __name__ == '__main__':
	fullPath = "./FullImgs"

	while True:
		imageInput = input("Enter image name : ")

		if imageInput is not None:
			csvFile = open('image.csv','r')
			for line in csvFile:
				if imageInput in line:
					print("Image input = ", imageInput)
					split = line.rstrip("\n").split("/")
					imagePath = fullPath + "/" + split[len(split)-2] + "/" + split[len(split)-1]
					image = cv2.imread(imagePath)
					image = cv2.resize(image,(1000,1000))
					cv2.imshow("InputTag", image)
					cv2.waitKey(0)
					cv2.destroyAllWindows()
			csvFile.close()
