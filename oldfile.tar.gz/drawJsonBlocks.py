import json 
import cv2

def drawBlock(imageName,jsonName):
	try:
		jsonData = json.load(open(jsonName,'r'))
	except:
		print("JSON not found !!!!!")
		return
		
	image = cv2.imread(imageName)
	blocks = jsonData['pages'][0]['blocks']
	for block in blocks:
		x1 = block['boundingBox']['vertices'][0]['x']
		y1 = block['boundingBox']['vertices'][0]['y']
		x2 = block['boundingBox']['vertices'][2]['x']
		y2 = block['boundingBox']['vertices'][2]['y']

		cv2.rectangle(image, (x1,y1), (x2,y2), (0,255,255), 2)
	
	image = cv2.resize(image,(0,0),fx=0.25,fy=0.25)
	cv2.imshow(jsonName, image)
	cv2.waitKey(0)

if __name__ == '__main__':
	fullImagePath = './FullImgs'
	jsonImagePath = './GVRaw'
	csvFile = 'image.csv'

	file = open(csvFile,'r')
	for line in file:
		split = line.rstrip('\n').split('/')
		
		imageName = fullImagePath + '/' + split[len(split)-2] + '/' + split[len(split)-1]

		fileName,extension = split[len(split)-1].split('.')
		jsonName =  jsonImagePath + '/' + fileName + '.txt'
		drawBlock(imageName,jsonName)