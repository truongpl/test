import os
import json
import cv2
import numpy as np

unusedChar = ['&','=','!','(',')','*','-', '$','#',",","/"]
specialChar = ['.']

def preProcess(json_data):

	for i in range(0,len(json_data['pages'])):
		page_i = json_data['pages'][i]
		blocks = page_i['blocks']
		blockData = []
		for block in blocks:
			# Get paragraphs of block
			paragraphs = block['paragraphs']

			sentenceBlock = []
			propBlock = []
			blockPosition = []

			for paragraph in paragraphs:

				paraBlock = []
				words = paragraph['words']

				paraLen = len(words)
				for wordIdx in range(0,paraLen):
					string = ''
					wordLen = len(words[wordIdx]['symbols'])
					prop = 'CONT'

					for charIdx in range(0,wordLen):
						string += words[wordIdx]['symbols'][charIdx]['text']
						if charIdx == wordLen-1:
							charProp = words[wordIdx]['symbols'][charIdx]['property']
							if 'detectedBreak' in charProp.keys():
								prop = 'SPACE'
							else:
								prop = 'CONT'

					# Cat words and each properties for parsing purpose
					try:
						x1 = words[wordIdx]['boundingBox']['vertices'][0]['x']
					except:
						x1 = 0

					try:
						y1 = words[wordIdx]['boundingBox']['vertices'][0]['y']
					except:
						y1 = 0

					try:
						x2 = words[wordIdx]['boundingBox']['vertices'][2]['x']
					except:
						x2 = 0

					try:
						y2 = words[wordIdx]['boundingBox']['vertices'][2]['y']
					except:
						y2 = 0

					wordRect = [x1,y1,x2,y2]
					paraBlock.append({'text':string,'rect':wordRect,'prop':prop})

				# Sentence += para
				sentenceBlock.append(paraBlock)

			vertices = block['boundingBox']['vertices']
			try:
				x1 = vertices[0]['x']
			except:
				x1 = 0

			try:
				y1 = vertices[0]['y']
			except:
				y1 = 0

			try:
				x2 = vertices[2]['x']
			except:
				x2 = 0

			try:
				y2 = vertices[2]['y']
			except:
				y2 = 0
			
			# Rect
			sentenceRect = [x1,y1,x2,y2]
			blockData.append({'sentenceBlock':sentenceBlock,'rect':sentenceRect})

	return blockData

# Iterate over block to cat the result
def isVerticalLink(rect1,rect2,eps):
	result = False

	if (rect1[1] >= rect2[1] - eps and rect1[1] <= rect2[3] + eps) \
		or (rect1[3] >= rect2[1] - eps and rect1[3] <= rect2[3] + eps):
		result = True

	return result

def isLineLink(rect1,rect2,eps):
	result = False

	if np.abs(rect1[1]-rect2[1]) < eps and np.abs(rect1[3]-rect2[3]) < eps:
		result = True

	return result

def processBlockLink(blockLink):
	# Unwrap block
	uzipSentence = []
	for block in blockLink:
		for para in block['sentenceBlock']:
			for word in para:
				# print("Single word data = ", word)				
				uzipSentence.append(word) # word = {rect,prop,text}

	# Concat sentence
	sentenceLen = len(uzipSentence)
	wordsFlag = np.ones([sentenceLen], dtype=np.int32)

	linesGroup = []
	for i in range(0,sentenceLen):
		if wordsFlag[i] == 1:
			sentence = []
			sentence.append(uzipSentence[i])
			if i < sentenceLen-1:
				for j in range(i+1,sentenceLen):
					if wordsFlag[j] == 1:
						if isLineLink(uzipSentence[i]['rect'],uzipSentence[j]['rect'],20) == True:
							# print("Text ", uzipSentence[i], " link with text ", uzipSentence[j])
							sentence.append(uzipSentence[j])
							wordsFlag[j] = 0
			
			wordsFlag[i] = 0
			linesGroup.append(sentence)

	# Process each words of group
	result = ''
	for wordsGroup in linesGroup:
		rawString = ''
		for word in wordsGroup:
			rawString += word['text']
			if word['prop'] == 'SPACE':
				rawString += ' '

		string = ''
		for idx in range(0,len(rawString)):
			char = rawString[idx]
			if ord(char) <= 127 and char not in unusedChar:
				if ((char == '.' or char == ':') and (rawString[idx-1].isalpha() == True)):
					string += " "
				else:
					string += char
			else:
				string += " "
			# if ord(rawString[idx]) <= 127:
			# 	if rawString[idx] not in unusedChar:
			# 		string += rawString[idx]
			# 	else:
			# 		string += " "

		if string and string != ' ':
			# result.append(string)
			result += string

	result = " ".join(result.split())
	return result

def postProcess(blockData):
	# Return data
	result = []
	tmpResult = []
	blockLen = len(blockData)

	postLinkData = []

	# Block flag
	blockFlag = np.ones([blockLen], dtype=np.int32)
	for i in range(0,blockLen):
		if blockFlag[i] == 1:
			blockLink = []
			blockLink.append(blockData[i])
			if i < blockLen-1:
				for j in range(i+1,blockLen):
					if blockFlag[j] == 1:
						if isVerticalLink(blockData[i]['rect'],blockData[j]['rect'],20) == True \
							or isVerticalLink(blockData[j]['rect'],blockData[i]['rect'],20) == True:
								# print("Block ", j, " links with block ", i)
								blockLink.append(blockData[j])
								blockFlag[j] = 0

			blockFlag[i] = 0
			postLinkData.append(blockLink)

	# Process postLinkData
	finalResult = []
	for linkData in postLinkData:
		finalResult.append(processBlockLink(linkData))

	return finalResult

def convertTxt(sentenceList, fileName, fileExtension):
	# file = open(fileName,'w')
	totalSentences = len(sentenceList)

	for i in range(0,totalSentences):
		smallSentence = fileName + '_' + str(i) + '.' + fileExtension
		file = open(smallSentence,'w')

		for word in sentenceList[i]:
			string = word + '\n'
			file.write(string)

		file.close()

if __name__ == '__main__':
	GVOutputDir = './GVRaw'
	OutDir = './JsonPostprocess/'
	jsonFile = os.listdir(GVOutputDir)
	for file in jsonFile:
		# Get file name + extension for writing
		print("File name = ", file)
		fileName, extension = file.split('.')
		
		absolutePath = GVOutputDir + "/" + file
		json_data = json.load(open(absolutePath,'r'))
		blockData = preProcess(json_data)
		sentenceList = postProcess(blockData)

		outName = OutDir + file
		writeFile = open(outName,'w')
		for sentence in sentenceList:
			writeFile.write(sentence)
			writeFile.write('\n')

		writeFile.close()

		# moveCommand = 'mv ' + file + ' ' + OutDir
		# os.system(moveCommand)

# if __name__ == '__main__':
# 	VisionOutput = './GVRaw'
# 	RawOut = './RawSentenceOut'
# 	jsonFile = os.listdir(VisionOutput)
# 	for file in jsonFile:
# 		fileName,extension = file.split('.')
# 		absPath = VisionOutput + "/" + file
		
# 		jsondata = json.load(open(absPath,'r'))
		
# 		postString = ''
# 		text = jsondata['text']
# 		text.replace('\n',' ')

# 		textLen = len(text)
# 		for idx in range(0,textLen):
# 			char = text[idx]
# 			if ord(char) <= 127 and char not in unusedChar:
# 				if ((char == '.' or char == ':') and (text[idx-1].isalpha() == True)):
# 					# print("Char = ", char, "previous char = ", text[idx-1], "isChar = ",\
# 					# 		text[idx-1].isalpha())
# 					postString += " "
# 				else:
# 					postString += char
# 				# postString += char
# 			else:
# 				postString += " "

# 		postString = " ".join(postString.split())				
# 		outName = RawOut + "/" + file
# 		writeFile = open(outName,'w')
# 		words = postString.split(" ")

# 		for word in words:
# 			writeFile.write(word)
# 			writeFile.write('\n')

# 		writeFile.close()

		# moveCommand = "mv " + file + " " + RawOut
		# os.system(moveCommand)




