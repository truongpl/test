from itertools import chain 

import nltk
import sklearn
import scipy.stats

import sklearn_crfsuite
nltk.corpus.conll2002.fileids()

train_sents = list(nltk.corpus.conll2002.iob_sents('esp.train'))
# test_sents = list(nltk.corpus.conll2002.iob_sents('esp.test'))

print(train_sents[0])

def word2features(sent,i):
	word = sent[i][0]
	postag = sent[i][1]

	features = {
		'bias':1.0,
		'word.lower()':word.lower(),
		'word[-3:]':word[-3:],
	}

	return features

def sent2features(sent):
	return [word2features(sent,i) for i in range(len(sent))]

print("AAAAAAAAAA",sent2features(train_sents[0]))