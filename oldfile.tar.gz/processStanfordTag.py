# This function only support for stanford tagging tool
def getTagInfo(singleTaggedFile):
	f = open(singleTaggedFile,'r')
	for line in f:
		name = ''
		entType = ''
		if 'tag name' in  line:
			# Split to small components
			ans = line.split(' ')

			# Get correct name
			name = ans[2].lstrip('value="start"/>').rstrip('<tag')

			# Get entity type
			entType = ans[1].lstrip('name="').rstrip('"')
		else:
			name = line
			entType = 'O'

		print("Line content = ", name, " with tagged name = ", entType)

if __name__ == '__main__':
	getTagInfo('./TagSentenceOut/output_9.txt')